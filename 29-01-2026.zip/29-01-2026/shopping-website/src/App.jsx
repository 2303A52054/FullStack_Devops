import React, { useState } from 'react';
import ProductList from './components/ProductList';
import Cart from './components/Cart';
import './App.css';

function App() {
  const [cart, setCart] = useState([]);

  const products = [
    {
      id: 1,
      name: 'Wireless Headphones',
      price: 79.99,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
      description: 'High-quality wireless headphones with noise cancellation',
      category: 'Electronics'
    },
    {
      id: 2,
      name: 'Smart Watch',
      price: 199.99,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop',
      description: 'Feature-rich smartwatch with fitness tracking',
      category: 'Electronics'
    },
    {
      id: 3,
      name: 'Laptop Backpack',
      price: 49.99,
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop',
      description: 'Durable backpack with laptop compartment',
      category: 'Accessories'
    },
    {
      id: 4,
      name: 'Coffee Maker',
      price: 89.99,
      image: 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=400&h=400&fit=crop',
      description: 'Programmable coffee maker with thermal carafe',
      category: 'Home'
    },
    {
      id: 5,
      name: 'Yoga Mat',
      price: 29.99,
      image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400&h=400&fit=crop',
      description: 'Non-slip yoga mat with carrying strap',
      category: 'Fitness'
    },
    {
      id: 6,
      name: 'Desk Lamp',
      price: 39.99,
      image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&h=400&fit=crop',
      description: 'LED desk lamp with adjustable brightness',
      category: 'Home'
    }
  ];

  const addToCart = (product) => {
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      setCart(cart.map(item =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity === 0) {
      removeFromCart(productId);
    } else {
      setCart(cart.map(item =>
        item.id === productId
          ? { ...item, quantity: newQuantity }
          : item
      ));
    }
  };

  return (
    <div className="App">
      <header className="header">
        <h1>🛒 ShopHub</h1>
        <p>Your one-stop shop for everything</p>
      </header>

      <div className="container">
        <div className="main-content">
          <ProductList products={products} addToCart={addToCart} />
        </div>
        
        <div className="sidebar">
          <Cart 
            cart={cart} 
            removeFromCart={removeFromCart}
            updateQuantity={updateQuantity}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
