# Shopping Website - React Project

## Overview
A dynamic online shopping website built with React where product data is passed from parent components to child components.

## Features
- **Dynamic Product Display**: Products are rendered as separate components
- **Props-based Data Flow**: Product data passed from parent to child components
- **Shopping Cart**: Add/remove items, update quantities
- **Responsive Design**: Works on desktop and mobile devices
- **Modern UI**: Beautiful gradient design with smooth animations

## Component Structure
```
App (Parent)
├── ProductList
│   └── ProductCard (receives product props)
└── Cart
```

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Extract the zip file
2. Navigate to the project directory:
   ```bash
   cd shopping-website
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

5. Open your browser and visit: `http://localhost:5173`

## How Props are Used

### Parent Component (App.jsx)
- Stores the products array
- Passes individual product data to ProductCard via ProductList
- Manages cart state

### Child Component (ProductCard.jsx)
- Receives product data via props: `{product, addToCart}`
- Displays: name, price, image, description, category
- Handles add to cart action

### Example Props Flow:
```javascript
// In App.jsx
<ProductList products={products} addToCart={addToCart} />

// In ProductList.jsx
<ProductCard product={product} addToCart={addToCart} />

// In ProductCard.jsx
const ProductCard = ({ product, addToCart }) => {
  // Use product.name, product.price, etc.
}
```

## Project Structure
```
shopping-website/
├── src/
│   ├── components/
│   │   ├── ProductList.jsx
│   │   ├── ProductList.css
│   │   ├── ProductCard.jsx
│   │   ├── ProductCard.css
│   │   ├── Cart.jsx
│   │   └── Cart.css
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## Technologies Used
- React 18
- Vite (Build tool)
- CSS3 (Styling)

## Key Concepts Demonstrated
1. **Component Props**: Passing data from parent to child
2. **State Management**: Using useState for cart functionality
3. **Component Composition**: Building UI with reusable components
4. **Event Handling**: onClick handlers for user interactions
5. **Conditional Rendering**: Showing empty cart message

## Customization
To add more products, edit the `products` array in `App.jsx`:
```javascript
{
  id: 7,
  name: 'Your Product',
  price: 99.99,
  image: 'image-url',
  description: 'Product description',
  category: 'Category'
}
```

## License
MIT
