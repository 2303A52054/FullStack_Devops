import React, { useState } from 'react';
import './EventDetails.css';

const EventDetails = ({ event, onClose, onEdit, onDelete, onAddParticipant, onRemoveParticipant }) => {
  const [showParticipantForm, setShowParticipantForm] = useState(false);
  const [participant, setParticipant] = useState({
    name: '',
    email: '',
    phone: ''
  });

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleAddParticipant = (e) => {
    e.preventDefault();
    
    if (!participant.name || !participant.email) {
      alert('Please fill in name and email');
      return;
    }

    onAddParticipant(event._id, participant);
    setParticipant({ name: '', email: '', phone: '' });
    setShowParticipantForm(false);
  };

  return (
    <div className="event-details">
      <div className="details-header">
        <h2>{event.title}</h2>
        <button className="close-btn" onClick={onClose}>&times;</button>
      </div>

      <div className="status-info">
        <span className={`status-tag ${event.status.toLowerCase()}`}>
          {event.status}
        </span>
        <span className="category-tag">{event.category}</span>
      </div>

      <div className="details-content">
        <div className="detail-item">
          <strong>📅 Date:</strong>
          <span>{formatDate(event.date)}</span>
        </div>

        <div className="detail-item">
          <strong>📍 Location:</strong>
          <span>{event.location}</span>
        </div>

        {event.capacity && (
          <div className="detail-item">
            <strong>👥 Capacity:</strong>
            <span>{event.participants?.length || 0} / {event.capacity}</span>
          </div>
        )}

        {event.description && (
          <div className="detail-item">
            <strong>📝 Description:</strong>
            <p>{event.description}</p>
          </div>
        )}

        <div className="participants-section">
          <div className="section-header">
            <h3>Participants ({event.participants?.length || 0})</h3>
            <button 
              className="btn-add-participant"
              onClick={() => setShowParticipantForm(!showParticipantForm)}
            >
              {showParticipantForm ? 'Cancel' : '+ Add Participant'}
            </button>
          </div>

          {showParticipantForm && (
            <form className="participant-form" onSubmit={handleAddParticipant}>
              <input
                type="text"
                placeholder="Name *"
                value={participant.name}
                onChange={(e) => setParticipant({...participant, name: e.target.value})}
                required
              />
              <input
                type="email"
                placeholder="Email *"
                value={participant.email}
                onChange={(e) => setParticipant({...participant, email: e.target.value})}
                required
              />
              <input
                type="tel"
                placeholder="Phone"
                value={participant.phone}
                onChange={(e) => setParticipant({...participant, phone: e.target.value})}
              />
              <button type="submit" className="btn-submit-participant">
                Add Participant
              </button>
            </form>
          )}

          {event.participants && event.participants.length > 0 ? (
            <div className="participants-list">
              {event.participants.map((p) => (
                <div key={p._id} className="participant-item">
                  <div className="participant-info">
                    <div className="participant-name">👤 {p.name}</div>
                    <div className="participant-contact">
                      <span>✉️ {p.email}</span>
                      {p.phone && <span>📞 {p.phone}</span>}
                    </div>
                  </div>
                  <button
                    className="btn-remove-participant"
                    onClick={() => onRemoveParticipant(event._id, p._id)}
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="no-participants">No participants yet</p>
          )}
        </div>

        <div className="detail-actions">
          <button className="btn-edit-detail" onClick={onEdit}>
            Edit Event
          </button>
          <button className="btn-delete-detail" onClick={onDelete}>
            Delete Event
          </button>
        </div>

        <div className="metadata">
          <small>Created: {new Date(event.createdAt).toLocaleString()}</small>
          <small>Updated: {new Date(event.updatedAt).toLocaleString()}</small>
        </div>
      </div>
    </div>
  );
};

export default EventDetails;
