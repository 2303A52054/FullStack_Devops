import React, { useState, useEffect } from 'react';
import expenseService from '../services/expenseService';
import ExpenseForm from './ExpenseForm';
import ExpenseList from './ExpenseList';
import MessageAlert from './MessageAlert';
import ExpenseStats from './ExpenseStats';
import './Expenses.css';

const Expenses = () => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [stats, setStats] = useState(null);

  // Fetch expenses on component mount
  useEffect(() => {
    fetchExpenses();
    fetchStats();
  }, []);

  // Fetch all expenses from backend
  const fetchExpenses = async () => {
    try {
      setLoading(true);
      const response = await expenseService.getAllExpenses();
      
      if (response.success) {
        setExpenses(response.data);
      } else {
        showMessage('error', 'Failed to fetch expenses');
      }
    } catch (error) {
      showMessage('error', error.message || 'Error loading expenses');
    } finally {
      setLoading(false);
    }
  };

  // Fetch statistics
  const fetchStats = async () => {
    try {
      const response = await expenseService.getExpenseStats();
      if (response.success) {
        setStats(response.data);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  // Add new expense
  const handleAddExpense = async (expenseData) => {
    try {
      const response = await expenseService.addExpense(expenseData);
      
      if (response.success) {
        // Update state with new expense
        setExpenses([response.data, ...expenses]);
        showMessage('success', 'Expense added successfully! 🎉');
        fetchStats(); // Update statistics
      } else {
        showMessage('error', response.message || 'Failed to add expense');
      }
    } catch (error) {
      showMessage('error', error.message || 'Error adding expense');
    }
  };

  // Delete expense
  const handleDeleteExpense = async (id) => {
    if (!window.confirm('Are you sure you want to delete this expense?')) {
      return;
    }

    try {
      const response = await expenseService.deleteExpense(id);
      
      if (response.success) {
        // Remove from state
        setExpenses(expenses.filter(exp => exp.id !== id));
        showMessage('success', 'Expense deleted successfully');
        fetchStats(); // Update statistics
      } else {
        showMessage('error', response.message || 'Failed to delete expense');
      }
    } catch (error) {
      showMessage('error', error.message || 'Error deleting expense');
    }
  };

  // Show message with auto-dismiss
  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => {
      setMessage({ type: '', text: '' });
    }, 4000);
  };

  // Calculate total expenses
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);

  return (
    <div className="expenses-container">
      <header className="expenses-header">
        <h1>💰 Personal Finance Tracker</h1>
        <p>Track and manage your expenses efficiently</p>
      </header>

      {/* Message Alert */}
      {message.text && (
        <MessageAlert type={message.type} message={message.text} />
      )}

      {/* Statistics */}
      {stats && <ExpenseStats stats={stats} />}

      {/* Add Expense Form */}
      <ExpenseForm onAddExpense={handleAddExpense} />

      {/* Expenses List */}
      <div className="expenses-list-section">
        <div className="list-header">
          <h2>Recent Expenses</h2>
          <div className="total-badge">
            Total: ${totalExpenses.toFixed(2)}
          </div>
        </div>

        {loading ? (
          <div className="loading-spinner">
            <div className="spinner"></div>
            <p>Loading expenses...</p>
          </div>
        ) : expenses.length === 0 ? (
          <div className="empty-state">
            <p>📝 No expenses yet. Add your first expense above!</p>
          </div>
        ) : (
          <ExpenseList 
            expenses={expenses} 
            onDeleteExpense={handleDeleteExpense}
          />
        )}
      </div>
    </div>
  );
};

export default Expenses;
