import React from 'react';
import './ExpenseItem.css';

const ExpenseItem = ({ expense, onDelete }) => {
  const { id, title, amount, category, date, description } = expense;

  // Format date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  // Get category emoji
  const getCategoryEmoji = (category) => {
    const emojiMap = {
      'Food': '🍔',
      'Transportation': '🚗',
      'Utilities': '💡',
      'Entertainment': '🎬',
      'Healthcare': '⚕️',
      'Shopping': '🛍️',
      'Education': '📚',
      'Other': '📌'
    };
    return emojiMap[category] || '📌';
  };

  return (
    <div className="expense-item">
      <div className="expense-item-header">
        <div className="expense-info">
          <span className="category-emoji">{getCategoryEmoji(category)}</span>
          <div className="expense-details">
            <h3 className="expense-title">{title}</h3>
            <div className="expense-meta">
              <span className="expense-category">{category}</span>
              <span className="expense-date">📅 {formatDate(date)}</span>
            </div>
          </div>
        </div>
        <div className="expense-actions">
          <span className="expense-amount">${amount.toFixed(2)}</span>
          <button 
            onClick={() => onDelete(id)}
            className="btn-delete"
            title="Delete expense"
          >
            🗑️
          </button>
        </div>
      </div>
      
      {description && (
        <div className="expense-description">
          <p>{description}</p>
        </div>
      )}
    </div>
  );
};

export default ExpenseItem;
