import React from 'react';
import './ExpenseStats.css';

const ExpenseStats = ({ stats }) => {
  const { total, count, byCategory } = stats;

  return (
    <div className="expense-stats">
      <div className="stat-card">
        <div className="stat-icon">💵</div>
        <div className="stat-info">
          <h3>Total Spent</h3>
          <p className="stat-value">${total.toFixed(2)}</p>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon">📊</div>
        <div className="stat-info">
          <h3>Total Expenses</h3>
          <p className="stat-value">{count}</p>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon">📈</div>
        <div className="stat-info">
          <h3>Average Expense</h3>
          <p className="stat-value">${count > 0 ? (total / count).toFixed(2) : '0.00'}</p>
        </div>
      </div>

      {Object.keys(byCategory).length > 0 && (
        <div className="stat-card category-breakdown">
          <div className="stat-icon">🏷️</div>
          <div className="stat-info">
            <h3>By Category</h3>
            <div className="category-list">
              {Object.entries(byCategory)
                .sort((a, b) => b[1] - a[1])
                .map(([category, amount]) => (
                  <div key={category} className="category-item">
                    <span className="category-name">{category}</span>
                    <span className="category-amount">${amount.toFixed(2)}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpenseStats;
