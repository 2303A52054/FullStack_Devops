# Personal Finance Tracker - React + Node.js

A full-stack expense tracking application with React frontend and Express backend.

## 📋 Features

✅ View all expenses from backend database  
✅ Add new expenses with validation  
✅ Delete expenses  
✅ Real-time UI updates (no page reload)  
✅ Success/Error message alerts  
✅ Expense statistics dashboard  
✅ Form validation  
✅ Responsive design  

## 🛠️ Tech Stack

**Frontend:**
- React 18
- Axios for API calls
- CSS3 for styling

**Backend:**
- Node.js
- Express.js
- CORS enabled
- In-memory database (array)

## 📁 Project Structure

```
finance-tracker/
├── backend/
│   ├── server.js           # Express server with CRUD APIs
│   └── package.json
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── Expenses.js       # Main component
│   │   │   ├── ExpenseForm.js    # Add expense form
│   │   │   ├── ExpenseList.js    # List container
│   │   │   ├── ExpenseItem.js    # Individual expense
│   │   │   ├── MessageAlert.js   # Success/Error alerts
│   │   │   ├── ExpenseStats.js   # Statistics dashboard
│   │   │   └── *.css            # Component styles
│   │   ├── services/
│   │   │   └── expenseService.js # API service
│   │   ├── App.js
│   │   ├── App.css
│   │   ├── index.js
│   │   └── index.css
│   └── package.json
└── README.md
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation & Setup

#### Step 1: Install Backend Dependencies

Open VS Code terminal and run:

```bash
cd backend
npm install
```

#### Step 2: Install Frontend Dependencies

In a new terminal:

```bash
cd frontend
npm install
```

#### Step 3: Start the Backend Server

In the backend terminal:

```bash
npm start
```

You should see:
```
✅ Server is running on http://localhost:5000
📊 API Endpoints:
   GET    /api/expenses - Fetch all expenses
   POST   /api/expenses - Add new expense
   ...
```

#### Step 4: Start the Frontend

In the frontend terminal:

```bash
npm start
```

The app will open automatically at `http://localhost:3000`

## 🔌 API Endpoints

### GET /api/expenses
Fetch all expenses

**Response:**
```json
{
  "success": true,
  "count": 3,
  "data": [
    {
      "id": 1,
      "title": "Grocery Shopping",
      "amount": 85.50,
      "category": "Food",
      "date": "2024-02-05",
      "description": "Weekly groceries"
    }
  ]
}
```

### POST /api/expenses
Add a new expense

**Request Body:**
```json
{
  "title": "Coffee",
  "amount": 5.50,
  "category": "Food",
  "date": "2024-02-09",
  "description": "Morning coffee"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Expense added successfully",
  "data": {
    "id": 4,
    "title": "Coffee",
    "amount": 5.50,
    "category": "Food",
    "date": "2024-02-09",
    "description": "Morning coffee"
  }
}
```

### DELETE /api/expenses/:id
Delete an expense

**Response:**
```json
{
  "success": true,
  "message": "Expense deleted successfully",
  "data": { /* deleted expense */ }
}
```

### GET /api/expenses/stats/summary
Get expense statistics

**Response:**
```json
{
  "success": true,
  "data": {
    "total": 221.49,
    "count": 3,
    "byCategory": {
      "Food": 85.50,
      "Utilities": 120.00,
      "Entertainment": 15.99
    }
  }
}
```

## 📝 How It Works

### 1. **Data Flow**

```
User Input → ExpenseForm → Validation → API Call → Backend → Database Update → UI Update
```

### 2. **State Management**

The main `Expenses` component manages:
- `expenses[]` - List of all expenses
- `loading` - Loading state
- `message` - Success/Error messages
- `stats` - Expense statistics

### 3. **API Integration**

The `expenseService.js` centralizes all API calls:

```javascript
// Fetch expenses
const response = await expenseService.getAllExpenses();

// Add expense
const response = await expenseService.addExpense(expenseData);

// Delete expense
const response = await expenseService.deleteExpense(id);
```

### 4. **Form Validation**

Before submitting, the form validates:
- ✅ Title is required (min 3 characters)
- ✅ Amount is required (must be positive number)
- ✅ Category is required
- ✅ Date is required (cannot be in future)

## 🎯 Bonus Features Implemented

✅ **Form Validation** - All inputs validated before submission  
✅ **Success/Error Messages** - Alert component with auto-dismiss  
✅ **Loading States** - Spinner while fetching data  
✅ **Statistics Dashboard** - Total spent, count, average, by category  
✅ **Responsive Design** - Mobile-friendly interface  
✅ **Empty State** - Helpful message when no expenses  
✅ **Delete Confirmation** - Prevent accidental deletions  

## 🎨 UI Features

- **Modern Design** - Gradient backgrounds, smooth animations
- **Category Emojis** - Visual category indicators
- **Hover Effects** - Interactive card animations
- **Color-Coded** - Success (green), Error (red) messages
- **Date Formatting** - Human-readable dates

## 🧪 Testing the App

1. **View Existing Expenses** - Should see 3 pre-loaded expenses
2. **Add New Expense:**
   - Fill in all required fields
   - Click "Add Expense"
   - See success message
   - New expense appears at top of list
3. **Form Validation:**
   - Try submitting empty form → See error messages
   - Enter negative amount → See validation error
   - Select future date → See validation error
4. **Delete Expense:**
   - Click trash icon
   - Confirm deletion
   - See success message
   - Expense removed from list

## 🔧 Customization

### Adding More Categories

Edit `ExpenseForm.js`:

```javascript
const categories = [
  'Food',
  'Transportation',
  'Your New Category', // Add here
  // ...
];
```

### Changing Port

**Backend** - Edit `server.js`:
```javascript
const PORT = 5000; // Change port
```

**Frontend** - Edit `package.json`:
```json
"proxy": "http://localhost:YOUR_PORT"
```

## 📚 Key Concepts Demonstrated

1. **REST API Integration** - GET, POST, DELETE requests
2. **React Hooks** - useState, useEffect
3. **Component Architecture** - Modular, reusable components
4. **State Management** - Lifting state up, prop drilling
5. **Form Handling** - Controlled components, validation
6. **Error Handling** - Try-catch, user feedback
7. **Async Operations** - Promises, async/await
8. **Responsive Design** - Mobile-first CSS

## 🐛 Troubleshooting

**Issue:** Cannot fetch expenses  
**Solution:** Ensure backend is running on port 5000

**Issue:** CORS errors  
**Solution:** Backend has CORS enabled, check if both servers are running

**Issue:** Module not found  
**Solution:** Run `npm install` in both backend and frontend folders

**Issue:** Port already in use  
**Solution:** Change port in server.js or kill existing process

## 📄 Commands Reference

### Backend
```bash
cd backend
npm install          # Install dependencies
npm start           # Start server (port 5000)
npm run dev         # Start with nodemon (auto-reload)
```

### Frontend
```bash
cd frontend
npm install          # Install dependencies
npm start           # Start dev server (port 3000)
npm run build       # Build for production
```

## 🎓 Learning Resources

- [React Documentation](https://react.dev)
- [Express.js Guide](https://expressjs.com)
- [Axios Documentation](https://axios-http.com)
- [REST API Tutorial](https://restfulapi.net)

## 📝 Notes

- Data is stored in memory (resets on server restart)
- For production, integrate with MongoDB/PostgreSQL
- Authentication not implemented (future enhancement)
- No data persistence across sessions

## 🚀 Future Enhancements

- [ ] Database integration (MongoDB/PostgreSQL)
- [ ] User authentication
- [ ] Edit expense functionality
- [ ] Filter by category/date
- [ ] Export to CSV
- [ ] Charts and graphs
- [ ] Budget tracking
- [ ] Recurring expenses

## 📧 Support

For issues or questions, refer to:
- React Docs: https://react.dev
- Express Docs: https://expressjs.com

---

**Happy Coding! 💻✨**
