# 🚀 QUICK START GUIDE

## Step-by-Step Commands for VS Code Terminal

### 1️⃣ Extract the ZIP file
After downloading, extract `finance-tracker.zip` to your desired location.

### 2️⃣ Open Project in VS Code
```bash
# Navigate to the project folder
cd finance-tracker

# Open in VS Code
code .
```

### 3️⃣ Open TWO Terminals in VS Code
Press `Ctrl + Shift + `` (backtick) to open terminal
Click the "+" icon to open a second terminal

---

## Terminal 1: Backend Server

```bash
# Navigate to backend folder
cd backend

# Install dependencies (first time only)
npm install

# Start the server
npm start
```

**Expected Output:**
```
✅ Server is running on http://localhost:5000
📊 API Endpoints:
   GET    /api/expenses - Fetch all expenses
   POST   /api/expenses - Add new expense
   ...
```

✅ **Keep this terminal running!**

---

## Terminal 2: Frontend React App

```bash
# Navigate to frontend folder
cd frontend

# Install dependencies (first time only)
npm install

# Start React app
npm start
```

**Expected Output:**
```
Compiled successfully!

You can now view finance-tracker-frontend in the browser.

  Local:            http://localhost:3000
```

✅ **Browser will open automatically at http://localhost:3000**

---

## 🎉 You're Done!

The app should now be running with:
- **Backend API:** http://localhost:5000
- **Frontend App:** http://localhost:3000

### Test the App:

1. ✅ View existing expenses (3 pre-loaded)
2. ✅ Add a new expense using the form
3. ✅ See it appear in the list without page reload
4. ✅ Delete an expense
5. ✅ Check statistics dashboard

---

## 🔄 Stopping the App

**To stop the servers:**
- Press `Ctrl + C` in each terminal
- Type `y` if prompted

**To restart:**
- Backend: `npm start` (in backend folder)
- Frontend: `npm start` (in frontend folder)

---

## ⚡ Understanding POST Requests

### What happens when you add an expense?

1. **User fills the form** → Title, Amount, Category, Date
2. **Validation runs** → Checks if all fields are valid
3. **POST request sent** → Axios sends data to backend
4. **Backend processes** → Validates and adds to database
5. **Response received** → Success or error message
6. **UI updates** → New expense appears in list

### POST Request Example:

**Code in `ExpenseForm.js`:**
```javascript
const handleAddExpense = async (expenseData) => {
  const response = await expenseService.addExpense(expenseData);
  // expenseData = { title, amount, category, date, description }
}
```

**What gets sent to backend:**
```json
{
  "title": "Coffee",
  "amount": 5.50,
  "category": "Food",
  "date": "2024-02-09",
  "description": "Morning coffee"
}
```

**Backend in `server.js` receives it:**
```javascript
app.post('/api/expenses', (req, res) => {
  const { title, amount, category, date, description } = req.body;
  // Validate and add to database
  // Send response back
});
```

**Response sent back:**
```json
{
  "success": true,
  "message": "Expense added successfully",
  "data": {
    "id": 4,
    "title": "Coffee",
    "amount": 5.50,
    ...
  }
}
```

### Where to find the code:

📁 **Frontend API Service:** `frontend/src/services/expenseService.js`
```javascript
addExpense: async (expenseData) => {
  const response = await api.post('/expenses', expenseData);
  return response.data;
}
```

📁 **Backend Handler:** `backend/server.js` (line ~80)
```javascript
app.post('/api/expenses', (req, res) => {
  // Validation
  // Create new expense
  // Return response
});
```

📁 **Form Component:** `frontend/src/components/ExpenseForm.js`
```javascript
const handleSubmit = async (e) => {
  e.preventDefault();
  if (!validateForm()) return;
  await onAddExpense(expenseData);
};
```

---

## 🛠️ Troubleshooting

**Problem:** `npm: command not found`  
**Solution:** Install Node.js from https://nodejs.org

**Problem:** Port 3000 already in use  
**Solution:** Kill the process or use different port

**Problem:** Cannot connect to backend  
**Solution:** Make sure backend terminal is running on port 5000

**Problem:** Module not found errors  
**Solution:** Delete `node_modules` folder and run `npm install` again

---

## 📚 Next Steps

1. Try adding different expenses
2. Explore the code in each file
3. Modify the categories in `ExpenseForm.js`
4. Change colors in CSS files
5. Add more API endpoints in `server.js`

---

**Need Help?** Check the full README.md for detailed documentation!
