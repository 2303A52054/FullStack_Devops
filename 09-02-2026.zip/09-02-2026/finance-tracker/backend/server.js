const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

// In-memory database (simulating a real database)
let expenses = [
  {
    id: 1,
    title: 'Grocery Shopping',
    amount: 85.50,
    category: 'Food',
    date: '2024-02-05',
    description: 'Weekly groceries from supermarket'
  },
  {
    id: 2,
    title: 'Electric Bill',
    amount: 120.00,
    category: 'Utilities',
    date: '2024-02-03',
    description: 'Monthly electricity payment'
  },
  {
    id: 3,
    title: 'Netflix Subscription',
    amount: 15.99,
    category: 'Entertainment',
    date: '2024-02-01',
    description: 'Monthly streaming service'
  }
];

let nextId = 4;

// GET /api/expenses - Fetch all expenses
app.get('/api/expenses', (req, res) => {
  try {
    // Sort by date (newest first)
    const sortedExpenses = [...expenses].sort((a, b) => 
      new Date(b.date) - new Date(a.date)
    );
    
    res.status(200).json({
      success: true,
      count: sortedExpenses.length,
      data: sortedExpenses
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching expenses',
      error: error.message
    });
  }
});

// GET /api/expenses/:id - Fetch single expense
app.get('/api/expenses/:id', (req, res) => {
  try {
    const expense = expenses.find(exp => exp.id === parseInt(req.params.id));
    
    if (!expense) {
      return res.status(404).json({
        success: false,
        message: 'Expense not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: expense
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching expense',
      error: error.message
    });
  }
});

// POST /api/expenses - Add a new expense
app.post('/api/expenses', (req, res) => {
  try {
    const { title, amount, category, date, description } = req.body;
    
    // Validation
    if (!title || !amount || !category || !date) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: title, amount, category, date'
      });
    }
    
    // Validate amount is a positive number
    if (isNaN(amount) || parseFloat(amount) <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Amount must be a positive number'
      });
    }
    
    // Create new expense
    const newExpense = {
      id: nextId++,
      title: title.trim(),
      amount: parseFloat(amount),
      category: category.trim(),
      date,
      description: description ? description.trim() : ''
    };
    
    expenses.push(newExpense);
    
    res.status(201).json({
      success: true,
      message: 'Expense added successfully',
      data: newExpense
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error adding expense',
      error: error.message
    });
  }
});

// PUT /api/expenses/:id - Update an expense
app.put('/api/expenses/:id', (req, res) => {
  try {
    const expenseIndex = expenses.findIndex(exp => exp.id === parseInt(req.params.id));
    
    if (expenseIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Expense not found'
      });
    }
    
    const { title, amount, category, date, description } = req.body;
    
    // Validation
    if (!title || !amount || !category || !date) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields'
      });
    }
    
    if (isNaN(amount) || parseFloat(amount) <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Amount must be a positive number'
      });
    }
    
    expenses[expenseIndex] = {
      ...expenses[expenseIndex],
      title: title.trim(),
      amount: parseFloat(amount),
      category: category.trim(),
      date,
      description: description ? description.trim() : ''
    };
    
    res.status(200).json({
      success: true,
      message: 'Expense updated successfully',
      data: expenses[expenseIndex]
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating expense',
      error: error.message
    });
  }
});

// DELETE /api/expenses/:id - Delete an expense
app.delete('/api/expenses/:id', (req, res) => {
  try {
    const expenseIndex = expenses.findIndex(exp => exp.id === parseInt(req.params.id));
    
    if (expenseIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Expense not found'
      });
    }
    
    const deletedExpense = expenses.splice(expenseIndex, 1)[0];
    
    res.status(200).json({
      success: true,
      message: 'Expense deleted successfully',
      data: deletedExpense
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting expense',
      error: error.message
    });
  }
});

// GET /api/expenses/stats/summary - Get expense statistics
app.get('/api/expenses/stats/summary', (req, res) => {
  try {
    const total = expenses.reduce((sum, exp) => sum + exp.amount, 0);
    const byCategory = expenses.reduce((acc, exp) => {
      acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
      return acc;
    }, {});
    
    res.status(200).json({
      success: true,
      data: {
        total: parseFloat(total.toFixed(2)),
        count: expenses.length,
        byCategory
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching statistics',
      error: error.message
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Server is running'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Server is running on http://localhost:${PORT}`);
  console.log(`📊 API Endpoints:`);
  console.log(`   GET    /api/expenses - Fetch all expenses`);
  console.log(`   GET    /api/expenses/:id - Fetch single expense`);
  console.log(`   POST   /api/expenses - Add new expense`);
  console.log(`   PUT    /api/expenses/:id - Update expense`);
  console.log(`   DELETE /api/expenses/:id - Delete expense`);
  console.log(`   GET    /api/expenses/stats/summary - Get statistics`);
});
